#!/usr/bin/env python3
"""
Shared Excel I/O helpers for the excel-validate-stats skill.

All scripts in this skill import from here so that:
- Column detection (库存数量 / 进价 / 5-key dedup columns) is consistent
- Decimal-safe cell reading is centralized
- Git-Bash style paths (/d/foo.xlsx) are normalized to Windows absolute
  paths so the scripts work regardless of how the caller passes the path.

No Java / JAR dependency. Pure openpyxl + stdlib.
"""

import re
from decimal import Decimal
from pathlib import Path

try:
    import openpyxl
except ImportError:
    raise SystemExit("错误: 需要安装 openpyxl 库，请运行: pip install openpyxl")


# 与对比/去重逻辑一致的关键列（用于判定"重复行"与差异键）
DUP_KEY_COLUMNS = [
    "外部商品编码",
    "库位",
    "供应商编码",
    "仓库供应商编码",
    "生产日期",
]


def normalize_path(p) -> Path:
    """
    Accept any of:
      - Windows absolute  D:\\data\\x.xlsx
      - Forward-slash     D:/data/x.xlsx
      - Git-Bash style    /d/data/x.xlsx   ->  D:/data/x.xlsx
    Returns a resolved absolute Path.
    """
    s = str(p).strip()
    # Git-Bash style: leading /<drive-letter>/
    m = re.match(r"^/([a-zA-Z])/(.*)$", s)
    if m:
        s = f"{m.group(1).upper()}:/{m.group(2)}"
    return Path(s)


def clean_header(h) -> str:
    """Clean a header cell: strip, drop leading '*', take first line."""
    if h is None:
        return ""
    s = str(h).strip()
    if s.startswith("*"):
        s = s[1:].strip()
    return s.split("\n")[0].strip()


def find_column(headers_clean, targets, fallback_keywords=None):
    """
    Find a column index by exact name first, then by keyword substring.
    Returns 0-based index or None.
    """
    if fallback_keywords is None:
        fallback_keywords = []
    for t in targets:
        for i, h in enumerate(headers_clean):
            if h == t:
                return i
    for kw in fallback_keywords:
        for i, h in enumerate(headers_clean):
            if kw in h:
                return i
    return None


def detect_qty_price_cols(headers_clean):
    """Return (qty_col_index, price_col_index) using exact-then-keyword fallback."""
    qty = find_column(headers_clean, ["库存数量"], ["库存", "数量", "现存", "结存"])
    price = find_column(headers_clean, ["进价"], ["进价", "单价", "价格", "成本"])
    return qty, price


def detect_key_indices(headers_clean):
    """
    Indices of the 5 dedup/diff key columns present in this file.

    Uses exact match first, then a substring fallback so headers with extra
    descriptive text (e.g. "外部商品编码 1.支持外部商家的商品编码 ...") still
    resolve to the right column instead of silently degrading to whole-row keys.
    """
    found = []
    for col_name in DUP_KEY_COLUMNS:
        # exact match
        idx = next((i for i, h in enumerate(headers_clean) if h == col_name), None)
        if idx is None:
            # substring fallback (first header containing the key name)
            idx = next((i for i, h in enumerate(headers_clean) if col_name in h), None)
        if idx is not None:
            found.append(idx)
    return found


def get_cell_decimal(cell):
    """Return a cell's value as Decimal, or None if absent/non-numeric."""
    if cell is None or cell.value is None:
        return None
    v = cell.value
    try:
        if isinstance(v, bool):
            return None
        if isinstance(v, (int, float)):
            return Decimal(str(v))
        if isinstance(v, str):
            s = v.strip()
            if not s:
                return None
            return Decimal(s)
        if isinstance(v, Decimal):
            return v
    except Exception:
        return None
    return None


def cell_key_value(cell):
    """Normalize a cell into a comparable string fragment for key building."""
    if cell is None or cell.value is None:
        return ""
    v = cell.value
    if isinstance(v, float):
        return str(Decimal(str(v)))
    return str(v).strip()


def build_row_key(row, key_indices, cleaned_headers):
    """
    Build the dedup/diff key for a row.
    Uses the detected key columns when present; otherwise falls back to the
    full row (matching the stats engine's degradation behavior).
    """
    if key_indices:
        return tuple(
            cell_key_value(row[i]) if i < len(row) else "" for i in key_indices
        )
    return tuple(cell_key_value(c) for c in row)


def load_sheet(path, header_row=1):
    """
    Load an Excel file for row-level processing.

    Returns a tuple:
        (workbook, raw_headers, cleaned_headers, rows, qty_col,
         price_col, key_indices)
    where `rows` is a list of openpyxl cell-row tuples (min_row = header_row+1).
    """
    p = normalize_path(path)
    wb = openpyxl.load_workbook(p, data_only=True)
    ws = wb.active
    raw_headers = [c.value for c in ws[header_row]]
    cleaned_headers = [clean_header(h) for h in raw_headers]
    rows = list(ws.iter_rows(min_row=header_row + 1, values_only=False))
    qty_col, price_col = detect_qty_price_cols(cleaned_headers)
    key_indices = detect_key_indices(cleaned_headers)
    return wb, raw_headers, cleaned_headers, rows, qty_col, price_col, key_indices


def insert_suffix(filename: str, suffix: str) -> str:
    """Insert suffix before the last dot: '1518-I.xlsx' + '_差异' -> '1518-I_差异.xlsx'."""
    dot = filename.rfind(".")
    if dot > 0:
        return filename[:dot] + suffix + filename[dot:]
    return filename + suffix
